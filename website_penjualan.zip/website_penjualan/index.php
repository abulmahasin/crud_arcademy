<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toko Abul Mahasin</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="responsive.css">
   
  </head>
  <body>
  <style type="text/css">

body {
background: url(gambar/gambar.jpg) no-repeat fixed;
   -webkit-background-size: 100% 100%;
   -moz-background-size: 100% 100%;
   -o-background-size: 100% 100%;
   background-size: 100% 100%;
}

</style>
    <header>
      <div class="container">
        <div class="header-left">
          <img class="logo" src="gambar/IconBali.png">
        </div>
    
        
       
        <div class="header-right">
          <a href="#">Home </a>
          <a href="inputan.php">Admin Panel</a>
          <!--<a href="#" class="login">Log in</a> -->
        </div>

      </div>
    </header>
    <div class="top-wrapper">
      <div class="container">
        <h1 >Belanja Bersama Kami</h1>
        <h1 >Dapatkan Kepuasan Anda</h1>
        <p>Hemat dan Terjangkau</p>

<!--
        <div class="btn-wrapper">
          <a href="#" class="btn facebook"><span></span>Belanja</a>
        </div>
-->

      </div>
    </div>
    
  </body>
</html>
